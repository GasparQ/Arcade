/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if on AIX 3.
   System headers sometimes define this.
   We just want to avoid a redefinition error message.  */
#ifndef _ALL_SOURCE
#undef _ALL_SOURCE
#endif

/* Define to empty if the keyword does not work.  */
//#undef const

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
//#undef size_t

/* Define if you have the ANSI C header files.  */
#undef STDC_HEADERS

/* Define if the Macintosh driver is compiled */
#define DRV_MAC

/* Define if you want a debug version of the library */
#undef MIKMOD_DEBUG
/* Define if you want runtime dynamic linking of ALSA and EsounD drivers */
#undef MIKMOD_DYNAMIC
/* Define if your system provides POSIX.4 threads */
#undef HAVE_PTHREAD

/* Define if your system has random(3) and srandom(3) */
#undef HAVE_SRANDOM
/* Define if your system defines random(3) and srandom(3) in math.h instead
   of stdlib.h */
#undef SRANDOM_IN_MATH_H

/* Define if you have the srandom function.  */
#undef HAVE_SRANDOM

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H

/* Define if you have the <malloc.h> header file.  */
#undef HAVE_MALLOC_H

/* Define if you have the <sys/ioctl.h> header file.  */
#undef HAVE_SYS_IOCTL_H

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H

/* Name of package */
#undef PACKAGE

/* Version number of package */
#undef VERSION

